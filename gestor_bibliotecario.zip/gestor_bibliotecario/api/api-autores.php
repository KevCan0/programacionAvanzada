<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Autor no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } elseif (isset($_GET['nacionalidad'])) {
            $nacionalidad = trim($_GET['nacionalidad']);
            $nacionalidad_param = "%$nacionalidad%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nacionalidad LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nacionalidad_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } elseif (isset($_GET['apellido'])) {
            $apellido = trim($_GET['apellido']);
            $apellido_param = "%$apellido%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE apellido LIKE ? ORDER BY id");
            $stmt->bind_param("s", $apellido_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
