    <footer>
        <p>&copy; <?= date("Y") ?> Gestor Bibliotecario &mdash; Sistema de administración de biblioteca</p>
    </footer>
</div>

<?php
    $scriptFile = __DIR__ . '/../assets/js/script.js';
    $scriptVersion = file_exists($scriptFile) ? filemtime($scriptFile) : time();
?>

    <script src="<?= htmlspecialchars($basePath ?? '') ?>assets/js/script.js?v=<?= $scriptVersion ?>"></script>

</body>
</html>
