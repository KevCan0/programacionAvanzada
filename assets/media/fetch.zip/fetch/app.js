const BASE_URL = "https://jsonplaceholder.typicode.com";

// GET
document.getElementById("btn-get-all").addEventListener("click", async () => { // Busca el elemento que tenga el id y le asigna un evento de click, el cual ejecuta una función asíncrona
    fetch(BASE_URL + "/posts")// Realiza una solicitud GET a la URL especificada "https://jsonplaceholder.typicode.com/posts"
        .then(response => { // La función then se ejecuta cuando la solicitud se completa, y recibe la respuesta como argumento. response es un objeto que representa la respuesta de la solicitud, y podemos acceder a sus propiedades, métodos, etc. Nota: el nombre de la variable response puede ser cualquiera, no es obligatorio que se llame así
            if(response.ok){ // Verifica si la respuesta fue exitosa
                return response.json(); // Si la respuesta es exitosa, se convierte a formato JSON
            }else{
                throw new Error("Error en la respuesta: " + response.status); // Si la respuesta no es exitosa, se lanza un error con el mensaje que incluye el código de estado de la respuesta
            }
        })
        .then(data =>{ // La función then se ejecuta justo después de haber convertido la respuesta a JSON. Nota: data es el resultado de la conversión a JSON, sin embargo, el nombre de la variable puede ser cualquiera
            alert("Petición realizada con éxito"); // Muestra una alerta indicando que la petición fue exitosa
            console.log("Respuesta de la petición:",data);
        })
        .catch(error =>{ // La función catch se ejecuta si ocurre un error en cualquiera de las funciones then anteriores, y recibe el error como argumento. Nota: el nombre de la variable error puede ser cualquiera
            alert("Ocurrió un error al realizar la petición"); // Muestra una alerta indicando que ocurrió un error
            console.error("Error en la petición:",error);
        })
});

document.getElementById("btn-get-one").addEventListener("click", async () => {
    fetch(BASE_URL + "/posts/1") // Realiza una solicitud GET a la URL especificada "https://jsonplaceholder.typicode.com/posts/1"
        .then(response => {
            if(response.ok){
                return response.json();
            }else{
                throw new Error("Error en la respuesta: " + response.status);
            }
        })
        .then(data =>{
            alert("Petición realizada con éxito");
            console.log("Respuesta de la petición: ", data);
        })
        .catch(error =>{
            alert("Ocurrió un error al realizar la petición");
            console.error("Error en la petición: ", error);
        })
});

// POST
document.getElementById("btn-post").addEventListener("click", async () => {
    fetch(BASE_URL + "/posts", {
        method: "POST", // Especificamos el método HTTP que utilizaremos para nuestra petición, en este caso, POST
        headers:{ // Los headers son un conjunto de campos que se envían junto con la solicitud HTTP para proporcionar información adicional sobre la solicitud o el cliente. Para este ejemplo, le vamos a especificar que el contenido enviado es de tipo JSON
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ // En esta parte, le proporcionamos a la solicitud el cuerpo de la petición, es decir la información que vamos a enviar al servidor. Utilizamos el método JSON.stringify() para convertir un objeto JavaScript a una cadena JSON.
            title: "Inauguración del mundial 2026",
            body: "El evento de la inauguración del mundial 2026 se llevará a cabo el 11 de junio de 2026 en el Estadio CDMX (Estadio Azteca), a las 11 AM. Posteriormente se llevará acabo el partido inaugural entre México vs Sudáfrica.",
            userId: 1
        })
    })
    .then(response => {
        if(response.ok){
            return response.json(); // En caso de que la respuesta sea exitosa, se devuelve la respuesta convertida en formato JSON
        }else{
            throw new Error(`Error en la respuesta: ${response.status}`); // En caso de que la respuesta no sea exitosa, se lanza un error con el mensaje que incluye el código de estado de la respuesta
        }
    })
    .then(data =>{
        alert("Post creado con éxito");
        console.log("Respuesta de la petición: ", data);
        const divResultPost = document.getElementById("post-result");
        divResultPost.innerHTML = `<p><strong>ID del nuevo post:</strong> ${data.id}</p><p><strong>Título del nuevo post:</strong> ${data.title}</p><p><strong>Contenido del nuevo post:</strong> ${data.body}</p>`; // Con innerHTML, asignamos nuevo contenido HTML al elemento divResultPost, donde mostraremos la información del nuevo post creado, utilizando la respuesta recibida en formato JSON
    })
    .catch(error =>{
        alert("Ocurrió un error al crear el post");
        console.error("Error en la petición: ", error);
        const divResultPost = document.getElementById("post-result");
        divResultPost.innerHTML = `<p style="color: red;"><strong>Error al crear el post:</strong> ${error.message}</p>`; 
    })
});

// PUT
document.getElementById("btn-put").addEventListener("click", async () => {
    fetch(BASE_URL + `/posts/1`,{
        method: "PUT", // Especificamos el método HTTP que utilizaremos. Para este ejemplo, usamos PUT
        headers:{
            "Content-Type": "application/json" // Especificamos que el contenido enviado es de tipo JSON
        },
        body: JSON.stringify({
            id: 1,
            title: "Actualización del post #1",
            body: "Actualizamos el contenido del post #1 para mostrar cómo funciona el método PUT en las solicitudes HTTP. En este caso, estamos reemplazando completamente el recurso existente con los nuevos datos proporcionados en el cuerpo de la solicitud.",
            userId: 1
        })
    })
    .then(response =>{
        if(response.ok){
            return response.json();
        }else{
            throw new Error(`Error en la respuesta: ${response.status}`);
        }
    })
    .then(data =>{
        alert("Post actualizado con éxito");
        console.log("Respuesta de la petición: ", data);
        const divResultPut = document.getElementById("put-result");
        divResultPut.innerHTML = `<p><strong>ID del post actualizado: </strong> ${data.id}</p><p><strong>Título del post actualizado: </strong> ${data.title}</p><p><strong>Contenido del post actualizado: </strong> ${data.body}</p>`;
    })
    .catch(error =>{
        alert("Ocurrió un error al actualizar el post");
        console.error("Error en la petición: ", error);
        const divResultPut = document.getElementById("put-result");
        divResultPut.innerHTML = `<p style="color: red;"><strong>Error al actualizar el post:</strong> ${error.message}</p>`;
    })
});

// DELETE
document.getElementById("btn-delete").addEventListener("click", async () => {
    fetch(BASE_URL + "/posts/1",{
        method: "DELETE" // Especificamos el método HTTP que utilizaremos. Para este ejemplo, usamos DELETE
    })
    .then(response =>{
        if(response.ok){
            return response.json();
        }else{
            throw new Error("Error en la respuesta: " + response.status);
        }
    })
    .then(data =>{
        alert("Post eliminado con éxito");
        console.log("Respuesta de la petición: ", data);
        const divResultDelete = document.getElementById("delete-result");
        divResultDelete.innerHTML = `<p><strong>Post eliminado: </strong> ${JSON.stringify(data)}</p>`;
    })
    .catch(error =>{
        alert("Ocurrió un error al eliminar el post");
        console.error("Error en la petición: ", error);
        const divResultDelete = document.getElementById("delete-result");
        divResultDelete.innerHTML = `<p style="color:red;"><strong>Error al eliminar el post: </strong> ${error.message}</p>`;
    })
});
