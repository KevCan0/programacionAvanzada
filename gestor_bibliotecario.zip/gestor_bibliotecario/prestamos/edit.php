<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $prestamo = $resultado->fetch_assoc();
    $stmt->close();

    if (!$prestamo) {
        $conn->close();
        header("Location: index.php?error=" . urlencode("Préstamo no encontrado"));
        exit;
    }

    $stmt = $conn->prepare("SELECT id, nombre, apellido FROM usuarios WHERE activo = 1 ORDER BY nombre");
    $stmt->execute();
    $resultado_usuarios = $stmt->get_result();
    $usuarios = [];
    while ($row = $resultado_usuarios->fetch_assoc()) {
        $usuarios[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id, titulo FROM libros ORDER BY titulo");
    $stmt->execute();
    $resultado_libros = $stmt->get_result();
    $libros = [];
    while ($row = $resultado_libros->fetch_assoc()) {
        $libros[] = $row;
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id, id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado_detalle = $stmt->get_result();
    $detalle = $resultado_detalle->fetch_assoc();
    $stmt->close();

    $conn->close();
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<?php if (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($prestamo["id"] ?? $id) ?>">

        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">-- Selecciona un usuario --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= htmlspecialchars($usuario["id"]) ?>" <?= $usuario["id"] == $prestamo["id_usuario"] ? 'selected' : '' ?>><?= htmlspecialchars($usuario["nombre"] . " " . $usuario["apellido"]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-alt"></i> Fecha Préstamo</label>
            <input type="date" name="fecha_prestamo" value="<?= htmlspecialchars($prestamo["fecha_prestamo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-check"></i> Fecha Devolución</label>
            <input type="date" name="fecha_devolucion" value="<?= htmlspecialchars($prestamo["fecha_devolucion"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-info-circle"></i> Estado</label>
            <select name="estado" required>
                <option value="">-- Selecciona un estado --</option>
                <option value="prestado" <?= $prestamo["estado"] === "prestado" ? 'selected' : '' ?>>Prestado</option>
                <option value="devuelto" <?= $prestamo["estado"] === "devuelto" ? 'selected' : '' ?>>Devuelto</option>
                <option value="retrasado" <?= $prestamo["estado"] === "retrasado" ? 'selected' : '' ?>>Retrasado</option>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libro</label>
            <select name="id_libro" required>
                <option value="">-- Selecciona un libro --</option>
                <?php foreach ($libros as $libro): ?>
                    <option value="<?= htmlspecialchars($libro["id"]) ?>" <?= isset($detalle["id_libro"]) && $libro["id"] == $detalle["id_libro"] ? 'selected' : '' ?>><?= htmlspecialchars($libro["titulo"]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-hashtag"></i> Cantidad</label>
            <input type="number" name="cantidad" min="1" value="<?= htmlspecialchars($detalle["cantidad"] ?? 1) ?>" placeholder="Ej: 1" required>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>