<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM detalle_prestamo WHERE id_prestamo = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: index.php?success=" . urlencode("Préstamo eliminado con éxito."));
        exit;
    } else {
        $error = $stmt->error;
        $stmt->close();
        $conn->close();
        header("Location: index.php?error=" . urlencode("Error al eliminar el préstamo: " . $error));
        exit;
    }
?>