<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE correo = ? ORDER BY id");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['id_rol'])) {
            $id_rol = intval($_GET['id_rol']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id_rol = ? ORDER BY id");
            $stmt->bind_param("i", $id_rol);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        }
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
